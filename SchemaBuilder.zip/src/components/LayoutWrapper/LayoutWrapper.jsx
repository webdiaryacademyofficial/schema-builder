const LayoutWrapper = ({ children }) => {
  return <div className="layout-wrapper | flex">{children}</div>;
};

export default LayoutWrapper;
