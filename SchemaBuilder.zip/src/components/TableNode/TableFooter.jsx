const TableFooter = () => {
  return (
    <div className="table-footer">
      <span> Scroll to see more columns</span>
    </div>
  );
};

export default TableFooter;
